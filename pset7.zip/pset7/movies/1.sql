SELECT title FROM movies WHERE year = 2008 LIMIT 10;
-- #1